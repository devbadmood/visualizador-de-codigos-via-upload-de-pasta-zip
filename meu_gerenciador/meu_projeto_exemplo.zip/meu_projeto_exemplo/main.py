def saudacao():
    print("Olá, este é um script Python de exemplo.")

if __name__ == "__main__":
    saudacao()
